-- V3 yönetim izinleri ve gerekli alanlar
alter table public.members add column if not exists avatar text;
alter table public.projects add column if not exists description text;
alter table public.units add column if not exists description text;

alter table public.members enable row level security;

drop policy if exists "public_insert_members" on public.members;
drop policy if exists "public_update_members" on public.members;
create policy "public_insert_members" on public.members for insert to anon, authenticated with check (true);
create policy "public_update_members" on public.members for update to anon, authenticated using (true) with check (true);

grant select, insert, update on public.members to anon;
grant select on public.units to anon;
grant select, insert, update on public.projects to anon;
grant select, insert, delete on public.project_members to anon;
grant select, insert, update on public.weekly_updates to anon;
grant select, insert, update on public.notifications to anon;

select 'V3 hazır' as durum;


-- ================================================================
-- KUDÜS BİLİNCİ DERNEĞİ EĞİTİM KOMİSYONU — PROFESYONEL V4
-- Bir kez Supabase > SQL Editor'da çalıştırın.
-- Mevcut verileri silmez.
-- ================================================================

create extension if not exists pgcrypto;

-- Proje sağlık durumu
alter table public.projects add column if not exists health_status text not null default 'on_track';
do $$ begin
  alter table public.projects add constraint projects_health_status_check
  check (health_status in ('on_track','at_risk','delayed','done'));
exception when duplicate_object then null; end $$;

-- Üye izinleri
create table if not exists public.member_permissions (
  member_id uuid primary key references public.members(id) on delete cascade,
  can_create_projects boolean not null default true,
  can_upload_files boolean not null default true,
  can_view_all_projects boolean not null default true,
  updated_at timestamptz not null default now()
);

insert into public.member_permissions(member_id)
select id from public.members
on conflict (member_id) do nothing;

-- Proje dosyaları ve bağlantılar
create table if not exists public.project_files (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  uploaded_by uuid references public.members(id) on delete set null,
  file_name text not null,
  file_url text,
  file_type text,
  external_url text,
  created_at timestamptz not null default now(),
  check (file_url is not null or external_url is not null)
);

-- Başkan parolası: hash dışında parola tutulmaz
create table if not exists public.app_settings (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

-- İlk kurulum parolası.
-- UYGULAMA YAYINA AÇILMADAN ÖNCE BAŞKAN GİRİŞİNDEN SONRA BUNU DEĞİŞTİRİN.
insert into public.app_settings(key,value)
values ('president_password_hash', crypt('Aksa-2026-IlkGiris!', gen_salt('bf')))
on conflict (key) do nothing;

create or replace function public.verify_president_password(p_password text)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists(
    select 1 from public.app_settings
    where key='president_password_hash'
      and value = crypt(p_password, value)
  );
$$;

create or replace function public.change_president_password(p_old_password text,p_new_password text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.verify_president_password(p_old_password) then return false; end if;
  if length(p_new_password) < 8 then return false; end if;
  update public.app_settings
  set value=crypt(p_new_password,gen_salt('bf')),updated_at=now()
  where key='president_password_hash';
  return true;
end;
$$;

grant execute on function public.verify_president_password(text) to anon, authenticated;
grant execute on function public.change_president_password(text,text) to anon, authenticated;

-- RLS
alter table public.member_permissions enable row level security;
alter table public.project_files enable row level security;

drop policy if exists "perm_read" on public.member_permissions;
drop policy if exists "perm_write" on public.member_permissions;
drop policy if exists "files_read" on public.project_files;
drop policy if exists "files_insert" on public.project_files;
drop policy if exists "files_delete" on public.project_files;

create policy "perm_read" on public.member_permissions for select to anon,authenticated using (true);
create policy "perm_write" on public.member_permissions for all to anon,authenticated using (true) with check (true);
create policy "files_read" on public.project_files for select to anon,authenticated using (true);
create policy "files_insert" on public.project_files for insert to anon,authenticated with check (true);
create policy "files_delete" on public.project_files for delete to anon,authenticated using (true);

grant select,insert,update on public.member_permissions to anon,authenticated;
grant select,insert,delete on public.project_files to anon,authenticated;
grant select,insert,update on public.projects to anon,authenticated;

-- Storage bucket: proje PDF/görselleri
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values(
  'project-files','project-files',true,15728640,
  array['application/pdf','image/jpeg','image/png','image/webp','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation']
)
on conflict(id) do update set public=true,file_size_limit=15728640;

drop policy if exists "project_files_storage_read" on storage.objects;
drop policy if exists "project_files_storage_insert" on storage.objects;
drop policy if exists "project_files_storage_delete" on storage.objects;

create policy "project_files_storage_read"
on storage.objects for select to anon,authenticated
using (bucket_id='project-files');

create policy "project_files_storage_insert"
on storage.objects for insert to anon,authenticated
with check (bucket_id='project-files');

create policy "project_files_storage_delete"
on storage.objects for delete to anon,authenticated
using (bucket_id='project-files');

-- Mevcut projeler için sağlık durumu varsayımı
update public.projects
set health_status = case
  when lower(coalesce(status,'')) in ('completed','tamamlandi','tamamlandı') then 'done'
  when lower(coalesce(status,'')) in ('late','gecikmis','gecikmiş') then 'delayed'
  when lower(coalesce(status,'')) in ('track','takip','takip gerekiyor') then 'at_risk'
  else coalesce(nullif(health_status,''),'on_track')
end;

select 'PROFESYONEL V4 HAZIR' as durum;


-- ================================================================
-- V5: ANKET / DUYURU / HATIRLATMA
-- ================================================================

create table if not exists public.polls (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  question text not null,
  created_by uuid references public.members(id) on delete set null,
  deadline timestamptz,
  is_active boolean not null default true,
  is_pinned boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.poll_options (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid not null references public.polls(id) on delete cascade,
  label text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.poll_votes (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid not null references public.polls(id) on delete cascade,
  option_id uuid not null references public.poll_options(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(poll_id, member_id)
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  kind text not null default 'announcement' check (kind in ('announcement','reminder')),
  event_at timestamptz,
  expires_at timestamptz,
  is_pinned boolean not null default true,
  created_by uuid references public.members(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table public.polls enable row level security;
alter table public.poll_options enable row level security;
alter table public.poll_votes enable row level security;
alter table public.announcements enable row level security;

drop policy if exists "polls_all" on public.polls;
drop policy if exists "poll_options_all" on public.poll_options;
drop policy if exists "poll_votes_all" on public.poll_votes;
drop policy if exists "announcements_all" on public.announcements;

create policy "polls_all" on public.polls for all to anon,authenticated using (true) with check (true);
create policy "poll_options_all" on public.poll_options for all to anon,authenticated using (true) with check (true);
create policy "poll_votes_all" on public.poll_votes for all to anon,authenticated using (true) with check (true);
create policy "announcements_all" on public.announcements for all to anon,authenticated using (true) with check (true);

grant select,insert,update,delete on public.polls to anon,authenticated;
grant select,insert,update,delete on public.poll_options to anon,authenticated;
grant select,insert,update,delete on public.poll_votes to anon,authenticated;
grant select,insert,update,delete on public.announcements to anon,authenticated;

select 'PROFESYONEL V5 HAZIR' as durum;

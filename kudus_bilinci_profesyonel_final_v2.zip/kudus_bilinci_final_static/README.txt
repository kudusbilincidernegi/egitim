KUDÜS BİLİNCİ DERNEĞİ EĞİTİM KOMİSYONU — SON SÜRÜM

Bu paket Lovable veya Netlify AI kredisi gerektirmez.
Uygulama doğrudan mevcut Supabase ortak veritabanına bağlanır.

İÇİNDEKİLER
- index.html : tüm uygulama
- assets/aksa-hero.jpg : Kudüs/Mescid-i Aksa tema görseli
- assets/avatar-ozlem.png : mevcut avatar dosyası

ÖZELLİKLER
- Ortak Supabase veritabanı
- Başkan paneli
- Üye ekle / düzenle / pasifleştir
- Proje oluştur / düzenle / arşivle
- Projeye üye ekle / çıkar
- Avatar / emoji değiştir
- Haftalık gelişme girişi
- Geçen hafta / bu hafta / gelecek hafta
- Destek talepleri
- Bildirim merkezi
- Pazar haftalık hatırlatma ekranı
- Mobil, Pinterest/pastel/Kudüs teması
- Şifresiz kişi seçimi

YAYINLAMA
Bu klasörü ücretsiz bir statik hosting servisine yükleyebilirsiniz. GitHub Pages veya Cloudflare Pages uygundur.
index.html kökte kalmalıdır.

GÜVENLİK NOTU
Uygulama kullanıcı isteği doğrultusunda şifresiz kişi seçimiyle çalışır. Bu gerçek kimlik doğrulama değildir.
Publishable Supabase anahtarı istemci tarafında kullanılmak üzere tasarlanmıştır; service_role/secret anahtarı bu pakette yoktur.


-- =====================================================================
-- KUDÜS BİLİNCİ DERNEĞİ EĞİTİM KOMİSYONU — V5.6 SON GELİŞTİRME
-- Mevcut verileri silmez. Bir kez Supabase SQL Editor'da çalıştırın.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

-- 1) Bildirimlerin okunma durumu artık HER ÜYEYE ÖZEL
create table if not exists public.notification_reads (
  notification_id uuid not null references public.notifications(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key(notification_id, member_id)
);

alter table public.notification_reads enable row level security;

drop policy if exists "notification_reads_all" on public.notification_reads;
create policy "notification_reads_all"
on public.notification_reads
for all
to anon,authenticated
using (true)
with check (true);

grant select,insert,update,delete on public.notification_reads to anon,authenticated;

-- Bildirimin hangi duyuru/rapordan geldiğini bağla.
alter table public.notifications add column if not exists source_type text;
alter table public.notifications add column if not exists source_id uuid;

grant select,insert,update,delete on public.notifications to anon,authenticated;

-- Eski duyuru bildirimlerini mümkün olduğunca ilgili duyuruya bağla.
update public.notifications n
set source_type='announcement',
    source_id=a.id
from public.announcements a
where n.source_id is null
  and n.type in ('announcement','reminder')
  and n.message = ('Özlem Başkan: ' || a.title);

-- 2) Başkan toplantı raporları
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  meeting_date date not null default current_date,
  is_published boolean not null default true,
  created_by uuid references public.members(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.reports enable row level security;

drop policy if exists "reports_all" on public.reports;
create policy "reports_all"
on public.reports
for all
to anon,authenticated
using (true)
with check (true);

grant select,insert,update,delete on public.reports to anon,authenticated;

-- 3) AKSA ŞENLİĞİ ve AJANDA birbirinden tamamen ayrı projeler
-- Gerekli birimleri garanti et.
insert into public.units(name)
select 'Aksa Şenliği'
where not exists (
  select 1 from public.units
  where lower(trim(name)) = lower(trim('Aksa Şenliği'))
);

insert into public.units(name)
select 'Eğitim'
where not exists (
  select 1 from public.units
  where lower(trim(name)) = lower(trim('Eğitim'))
);

-- Eğer daha önce Aksa ve Ajanda tek bir proje adı altında birleştirildiyse:
-- Ayrı Aksa Şenliği yoksa birleşik kaydı Aksa Şenliği olarak düzelt.
update public.projects p
set name='Aksa Şenliği',
    unit_id=(select id from public.units where lower(trim(name))=lower(trim('Aksa Şenliği')) limit 1),
    updated_at=now()
where p.id = (
  select p2.id
  from public.projects p2
  where p2.name ilike '%Aksa%'
    and p2.name ilike '%Ajanda%'
    and not exists (
      select 1 from public.projects px
      where lower(trim(px.name))=lower(trim('Aksa Şenliği'))
    )
  order by p2.created_at
  limit 1
);

-- Ayrı Aksa Şenliği projesini garanti et.
insert into public.projects(unit_id,name,status,health_status,progress,start_date)
select
  u.id,'Aksa Şenliği','active','on_track',0,current_date
from public.units u
where lower(trim(u.name))=lower(trim('Aksa Şenliği'))
  and not exists (
    select 1 from public.projects p
    where lower(trim(p.name))=lower(trim('Aksa Şenliği'))
  );

-- Ayrı Ajanda projesini garanti et.
insert into public.projects(unit_id,name,status,health_status,progress,start_date)
select
  u.id,'Ajanda','active','on_track',0,current_date
from public.units u
where lower(trim(u.name))=lower(trim('Eğitim'))
  and not exists (
    select 1 from public.projects p
    where lower(trim(p.name))=lower(trim('Ajanda'))
  );

-- Exact Aksa ve Ajanda zaten varsa eski birleşik Aksa+Ajanda projelerini arşivle.
update public.projects
set status='archived',updated_at=now()
where name ilike '%Aksa%'
  and name ilike '%Ajanda%'
  and lower(trim(name)) not in (lower(trim('Aksa Şenliği')),lower(trim('Ajanda')))
  and exists (select 1 from public.projects where lower(trim(name))=lower(trim('Aksa Şenliği')))
  and exists (select 1 from public.projects where lower(trim(name))=lower(trim('Ajanda')));

-- 4) Seda ve Safiye SADECE Aksa Şenliği'nde görevli.
delete from public.project_members pm
where pm.member_id in (
  select id from public.members
  where lower(trim(name)) in (lower(trim('Seda')),lower(trim('Safiye')))
)
and pm.project_id not in (
  select id from public.projects
  where lower(trim(name))=lower(trim('Aksa Şenliği'))
    and status <> 'archived'
);

insert into public.project_members(project_id,member_id)
select p.id,m.id
from public.projects p
cross join public.members m
where lower(trim(p.name))=lower(trim('Aksa Şenliği'))
  and p.status <> 'archived'
  and lower(trim(m.name)) in (lower(trim('Seda')),lower(trim('Safiye')))
  and not exists (
    select 1 from public.project_members pm
    where pm.project_id=p.id and pm.member_id=m.id
  );

-- 5) İzinler
grant select,insert,update,delete on public.projects to anon,authenticated;
grant select,insert,update,delete on public.project_members to anon,authenticated;

select
  'V5.6 HAZIR' as durum,
  (select count(*) from public.reports) as rapor_sayisi,
  (select count(*) from public.projects where lower(trim(name))=lower(trim('Aksa Şenliği'))) as aksa_senligi,
  (select count(*) from public.projects where lower(trim(name))=lower(trim('Ajanda'))) as ajanda;

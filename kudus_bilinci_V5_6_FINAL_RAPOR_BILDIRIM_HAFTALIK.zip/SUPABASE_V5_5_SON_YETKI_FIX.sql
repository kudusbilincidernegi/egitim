
-- ============================================================
-- V5.5 SON YETKİ DÜZELTMESİ
-- Başkan girişi + üye proje oluşturma için.
-- Mevcut verileri silmez.
-- ============================================================

-- Başkan fonksiyonları API'den çağrılabilsin
grant execute on function public.verify_president_password(text) to anon, authenticated;
grant execute on function public.change_president_password(text,text) to anon, authenticated;

-- Proje yönetim izinleri
grant select, insert, update, delete on public.projects to anon, authenticated;
grant select, insert, update, delete on public.project_members to anon, authenticated;
grant select, insert, update on public.notifications to anon, authenticated;

alter table public.projects enable row level security;
alter table public.project_members enable row level security;

drop policy if exists "v55_projects_insert" on public.projects;
drop policy if exists "v55_projects_update" on public.projects;
drop policy if exists "v55_projects_delete" on public.projects;
drop policy if exists "v55_pm_insert" on public.project_members;
drop policy if exists "v55_pm_update" on public.project_members;
drop policy if exists "v55_pm_delete" on public.project_members;

create policy "v55_projects_insert"
on public.projects for insert
to anon, authenticated
with check (true);

create policy "v55_projects_update"
on public.projects for update
to anon, authenticated
using (true) with check (true);

create policy "v55_projects_delete"
on public.projects for delete
to anon, authenticated
using (true);

create policy "v55_pm_insert"
on public.project_members for insert
to anon, authenticated
with check (true);

create policy "v55_pm_update"
on public.project_members for update
to anon, authenticated
using (true) with check (true);

create policy "v55_pm_delete"
on public.project_members for delete
to anon, authenticated
using (true);

select 'V5.5 SON YETKİLER HAZIR' as durum;
